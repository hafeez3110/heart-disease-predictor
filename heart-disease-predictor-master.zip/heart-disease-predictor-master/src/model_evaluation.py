"""
Model evaluation module for Heart Disease Prediction
Implements comprehensive model evaluation and comparison
"""
import pandas as pd
import numpy as np
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    confusion_matrix, classification_report, roc_auc_score,
    roc_curve
)
from src.utils import (
    plot_confusion_matrix, plot_roc_curve, 
    plot_feature_importance, plot_model_comparison,
    save_model
)


class ModelEvaluator:
    """Class to handle model evaluation and performance metrics"""
    
    def __init__(self):
        self.results = {}
        self.predictions = {}
        
    def evaluate_model(self, model, model_name, X_test, y_test, save_plots=True):
        """
        Evaluate a single model and return comprehensive metrics
        """
        print(f"\n{'='*80}")
        print(f"EVALUATING {model_name}")
        print('='*80)
        
        # Make predictions
        y_pred = model.predict(X_test)
        
        # Get prediction probabilities if available
        if hasattr(model, 'predict_proba'):
            y_pred_proba = model.predict_proba(X_test)[:, 1]
        else:
            # For models without predict_proba (like SVC without probability=True)
            y_pred_proba = y_pred
        
        # Calculate metrics
        accuracy = accuracy_score(y_test, y_pred)
        precision = precision_score(y_test, y_pred, zero_division=0)
        recall = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        
        # Calculate ROC-AUC if probabilities available
        try:
            roc_auc = roc_auc_score(y_test, y_pred_proba)
        except:
            roc_auc = np.nan
        
        # Store results
        self.results[model_name] = {
            'Accuracy': accuracy,
            'Precision': precision,
            'Recall': recall,
            'F1-Score': f1,
            'ROC-AUC': roc_auc
        }
        
        self.predictions[model_name] = {
            'y_pred': y_pred,
            'y_pred_proba': y_pred_proba
        }
        
        # Print results
        print(f"\n📊 Performance Metrics:")
        print(f"  Accuracy:  {accuracy:.4f}")
        print(f"  Precision: {precision:.4f}")
        print(f"  Recall:    {recall:.4f}")
        print(f"  F1-Score:  {f1:.4f}")
        if not np.isnan(roc_auc):
            print(f"  ROC-AUC:   {roc_auc:.4f}")
        
        # Print confusion matrix
        cm = confusion_matrix(y_test, y_pred)
        print(f"\n📊 Confusion Matrix:")
        print(f"  True Negatives:  {cm[0, 0]}")
        print(f"  False Positives: {cm[0, 1]}")
        print(f"  False Negatives: {cm[1, 0]}")
        print(f"  True Positives:  {cm[1, 1]}")
        
        # Print classification report
        print(f"\n📊 Classification Report:")
        print(classification_report(y_test, y_pred, 
                                   target_names=['No Disease', 'Disease']))
        
        # Save plots
        if save_plots:
            plot_confusion_matrix(y_test, y_pred, model_name)
            if not np.isnan(roc_auc):
                plot_roc_curve(y_test, y_pred_proba, model_name)
        
        return self.results[model_name]
    
    def evaluate_all_models(self, models, X_test, y_test, feature_names=None, save_plots=True):
        """
        Evaluate all models and create comparison
        """
        print("\n" + "="*80)
        print("EVALUATING ALL MODELS")
        print("="*80)
        
        for name, model in models.items():
            self.evaluate_model(model, name, X_test, y_test, save_plots)
            
            # Plot feature importance for tree-based models
            if save_plots and feature_names is not None:
                plot_feature_importance(model, feature_names, name)
        
        # Create comparison summary
        self.print_comparison_summary()
        
        # Create comparison plots
        if save_plots:
            results_df = self.get_results_dataframe()
            plot_model_comparison(results_df)
        
        return self.results
    
    def print_comparison_summary(self):
        """Print a summary comparison of all models"""
        print("\n" + "="*80)
        print("MODEL COMPARISON SUMMARY")
        print("="*80)
        
        results_df = self.get_results_dataframe()
        print("\n" + results_df.to_string(index=False))
        
        # Find best model for each metric
        print("\n" + "="*80)
        print("BEST MODELS BY METRIC")
        print("="*80)
        
        metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score', 'ROC-AUC']
        for metric in metrics:
            if metric in results_df.columns:
                best_idx = results_df[metric].idxmax()
                best_model = results_df.loc[best_idx, 'Model']
                best_score = results_df.loc[best_idx, metric]
                print(f"\n🏆 Best {metric}: {best_model} ({best_score:.4f})")
    
    def get_results_dataframe(self):
        """Convert results dictionary to pandas DataFrame"""
        df = pd.DataFrame(self.results).T
        df = df.reset_index().rename(columns={'index': 'Model'})
        return df
    
    def get_best_model(self, metric='Accuracy'):
        """Get the best performing model based on a specific metric"""
        if not self.results:
            print("✗ No evaluation results available")
            return None
        
        best_model_name = max(self.results.items(), 
                            key=lambda x: x[1].get(metric, 0))[0]
        best_score = self.results[best_model_name][metric]
        
        print(f"\n🏆 Best model by {metric}: {best_model_name} ({best_score:.4f})")
        return best_model_name
    
    def save_results(self, filepath='results/model_results.csv'):
        """Save evaluation results to CSV"""
        results_df = self.get_results_dataframe()
        results_df.to_csv(filepath, index=False)
        print(f"\n✓ Results saved to {filepath}")
    
    def compare_models_statistical(self, models, X_train, y_train, cv=10):
        """
        Perform statistical comparison of models using cross-validation
        """
        from sklearn.model_selection import cross_val_score
        
        print("\n" + "="*80)
        print("STATISTICAL MODEL COMPARISON")
        print("="*80)
        
        cv_results = {}
        
        for name, model in models.items():
            print(f"\n🔧 Cross-validating {name}...")
            scores = cross_val_score(model, X_train, y_train, cv=cv, scoring='accuracy')
            cv_results[name] = scores
            
            print(f"  Mean Accuracy: {scores.mean():.4f}")
            print(f"  Std Deviation: {scores.std():.4f}")
            print(f"  95% CI: [{scores.mean() - 1.96*scores.std():.4f}, "
                  f"{scores.mean() + 1.96*scores.std():.4f}]")
        
        return cv_results
    
    def detailed_error_analysis(self, model, model_name, X_test, y_test):
        """
        Perform detailed error analysis
        """
        print(f"\n{'='*80}")
        print(f"ERROR ANALYSIS - {model_name}")
        print('='*80)
        
        y_pred = model.predict(X_test)
        
        # Find misclassified samples
        errors = y_test != y_pred
        error_indices = np.where(errors)[0]
        
        print(f"\n📊 Total Errors: {errors.sum()} out of {len(y_test)} ({errors.sum()/len(y_test)*100:.2f}%)")
        
        # False positives and false negatives
        false_positives = np.sum((y_pred == 1) & (y_test == 0))
        false_negatives = np.sum((y_pred == 0) & (y_test == 1))
        
        print(f"\n  False Positives: {false_positives} (predicted disease, but no disease)")
        print(f"  False Negatives: {false_negatives} (predicted no disease, but has disease)")
        
        # Calculate error rates
        if len(y_test[y_test == 0]) > 0:
            fpr = false_positives / len(y_test[y_test == 0])
            print(f"  False Positive Rate: {fpr:.4f}")
        
        if len(y_test[y_test == 1]) > 0:
            fnr = false_negatives / len(y_test[y_test == 1])
            print(f"  False Negative Rate: {fnr:.4f}")
        
        return error_indices


class ModelSelector:
    """Class to help select the best model based on requirements"""
    
    def __init__(self, evaluator):
        self.evaluator = evaluator
        
    def select_best_overall(self):
        """Select best model based on F1-score (balance of precision and recall)"""
        return self.evaluator.get_best_model(metric='F1-Score')
    
    def select_for_sensitivity(self):
        """Select model with highest recall (minimize false negatives)"""
        return self.evaluator.get_best_model(metric='Recall')
    
    def select_for_specificity(self):
        """Select model with highest precision (minimize false positives)"""
        return self.evaluator.get_best_model(metric='Precision')
    
    def select_for_accuracy(self):
        """Select model with highest accuracy"""
        return self.evaluator.get_best_model(metric='Accuracy')


if __name__ == "__main__":
    # Example usage
    from src.data_preprocessing import DataPreprocessor
    from src.model_training import ModelTrainer
    
    # Load and prepare data
    preprocessor = DataPreprocessor()
    df = preprocessor.load_data()
    df_clean = preprocessor.clean_data(df)
    X_train, X_test, y_train, y_test = preprocessor.prepare_features(df_clean)
    
    # Train models
    trainer = ModelTrainer()
    trainer.initialize_models()
    models = trainer.train_basic_models(X_train, y_train)
    
    # Evaluate models
    evaluator = ModelEvaluator()
    results = evaluator.evaluate_all_models(models, X_test, y_test, 
                                           feature_names=preprocessor.feature_names)
    
    # Save results
    evaluator.save_results()
