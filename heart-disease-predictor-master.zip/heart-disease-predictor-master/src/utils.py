"""
Utility functions for the Heart Disease Prediction project
"""
import os
import joblib
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, roc_curve, auc


def create_directories():
    """Create necessary directories for the project"""
    directories = ['data', 'models', 'results', 'notebooks', 'src']
    for directory in directories:
        os.makedirs(directory, exist_ok=True)
    print("✓ Directories created successfully")


def save_model(model, model_name, directory='models'):
    """Save a trained model to disk"""
    os.makedirs(directory, exist_ok=True)
    filepath = os.path.join(directory, f'{model_name}.pkl')
    joblib.dump(model, filepath)
    print(f"✓ Model saved: {filepath}")


def load_model(model_name, directory='models'):
    """Load a trained model from disk"""
    filepath = os.path.join(directory, f'{model_name}.pkl')
    if os.path.exists(filepath):
        model = joblib.load(filepath)
        print(f"✓ Model loaded: {filepath}")
        return model
    else:
        print(f"✗ Model not found: {filepath}")
        return None


def plot_confusion_matrix(y_true, y_pred, model_name, save_path='results'):
    """Plot and save confusion matrix"""
    cm = confusion_matrix(y_true, y_pred)
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['No Disease', 'Disease'],
                yticklabels=['No Disease', 'Disease'])
    plt.title(f'Confusion Matrix - {model_name}')
    plt.ylabel('True Label')
    plt.xlabel('Predicted Label')
    
    os.makedirs(save_path, exist_ok=True)
    filepath = os.path.join(save_path, f'confusion_matrix_{model_name}.png')
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"✓ Confusion matrix saved: {filepath}")


def plot_roc_curve(y_true, y_pred_proba, model_name, save_path='results'):
    """Plot and save ROC curve"""
    fpr, tpr, _ = roc_curve(y_true, y_pred_proba)
    roc_auc = auc(fpr, tpr)
    
    plt.figure(figsize=(8, 6))
    plt.plot(fpr, tpr, color='darkorange', lw=2, 
             label=f'ROC curve (AUC = {roc_auc:.2f})')
    plt.plot([0, 1], [0, 1], color='navy', lw=2, linestyle='--', label='Random Classifier')
    plt.xlim([0.0, 1.0])
    plt.ylim([0.0, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f'ROC Curve - {model_name}')
    plt.legend(loc="lower right")
    plt.grid(alpha=0.3)
    
    os.makedirs(save_path, exist_ok=True)
    filepath = os.path.join(save_path, f'roc_curve_{model_name}.png')
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"✓ ROC curve saved: {filepath}")


def plot_feature_importance(model, feature_names, model_name, save_path='results'):
    """Plot and save feature importance for tree-based models"""
    if hasattr(model, 'feature_importances_'):
        importances = model.feature_importances_
        indices = np.argsort(importances)[::-1]
        
        plt.figure(figsize=(10, 6))
        plt.title(f'Feature Importance - {model_name}')
        plt.bar(range(len(importances)), importances[indices])
        plt.xticks(range(len(importances)), 
                   [feature_names[i] for i in indices], 
                   rotation=45, ha='right')
        plt.xlabel('Features')
        plt.ylabel('Importance')
        plt.tight_layout()
        
        os.makedirs(save_path, exist_ok=True)
        filepath = os.path.join(save_path, f'feature_importance_{model_name}.png')
        plt.savefig(filepath, dpi=300, bbox_inches='tight')
        plt.close()
        print(f"✓ Feature importance plot saved: {filepath}")


def plot_model_comparison(results_df, save_path='results'):
    """Plot comparison of all models"""
    metrics = ['Accuracy', 'Precision', 'Recall', 'F1-Score']
    
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.suptitle('Model Performance Comparison', fontsize=16, y=1.02)
    
    for idx, metric in enumerate(metrics):
        ax = axes[idx // 2, idx % 2]
        results_df.plot(x='Model', y=metric, kind='bar', ax=ax, legend=False, color='skyblue')
        ax.set_title(f'{metric} Comparison')
        ax.set_ylabel(metric)
        ax.set_xlabel('Model')
        ax.set_ylim([0, 1.0])
        ax.grid(axis='y', alpha=0.3)
        
        # Add value labels on bars
        for container in ax.containers:
            ax.bar_label(container, fmt='%.3f', padding=3)
        
        plt.setp(ax.xaxis.get_majorticklabels(), rotation=45, ha='right')
    
    plt.tight_layout()
    os.makedirs(save_path, exist_ok=True)
    filepath = os.path.join(save_path, 'model_comparison.png')
    plt.savefig(filepath, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"✓ Model comparison plot saved: {filepath}")


def print_separator(char='=', length=80):
    """Print a separator line"""
    print(char * length)
