"""
Data preprocessing module for Heart Disease Prediction
Handles data loading, cleaning, exploration, and feature engineering
"""
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
import os


class DataPreprocessor:
    """Class to handle all data preprocessing operations"""
    
    def __init__(self):
        self.scaler = StandardScaler()
        self.feature_names = None
        
    def load_data(self, url=None, filepath=None):
        """
        Load heart disease dataset from URL or local file
        Default: UCI Heart Disease dataset
        """
        if filepath and os.path.exists(filepath):
            print(f"Loading data from {filepath}...")
            df = pd.read_csv(filepath)
        else:
            # Default UCI Heart Disease dataset URL
            if url is None:
                url = "https://archive.ics.uci.edu/ml/machine-learning-databases/heart-disease/processed.cleveland.data"
            
            print(f"Loading data from {url}...")
            
            # Column names for the dataset
            columns = ['age', 'sex', 'cp', 'trestbps', 'chol', 'fbs', 
                      'restecg', 'thalach', 'exang', 'oldpeak', 'slope', 
                      'ca', 'thal', 'target']
            
            df = pd.read_csv(url, names=columns, na_values='?')
        
        print(f"✓ Data loaded successfully: {df.shape[0]} rows, {df.shape[1]} columns")
        return df
    
    def explore_data(self, df, save_plots=True):
        """Perform exploratory data analysis"""
        print("\n" + "="*80)
        print("DATA EXPLORATION")
        print("="*80)
        
        print("\n📊 Dataset Info:")
        print(df.info())
        
        print("\n📊 Statistical Summary:")
        print(df.describe())
        
        print("\n📊 Missing Values:")
        missing = df.isnull().sum()
        if missing.sum() > 0:
            print(missing[missing > 0])
        else:
            print("No missing values found")
        
        print("\n📊 Target Distribution:")
        target_counts = df['target'].value_counts()
        print(target_counts)
        print(f"\nTarget balance: {target_counts.values[0]/len(df)*100:.2f}% - {target_counts.values[1]/len(df)*100:.2f}%")
        
        if save_plots:
            self._create_eda_plots(df)
    
    def _create_eda_plots(self, df):
        """Create and save exploratory data analysis plots"""
        os.makedirs('results', exist_ok=True)
        
        # 1. Target distribution
        plt.figure(figsize=(8, 6))
        df['target'].value_counts().plot(kind='bar', color=['lightcoral', 'lightblue'])
        plt.title('Target Distribution (0: No Disease, 1: Disease)')
        plt.xlabel('Target')
        plt.ylabel('Count')
        plt.xticks(rotation=0)
        plt.tight_layout()
        plt.savefig('results/target_distribution.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 2. Correlation heatmap
        plt.figure(figsize=(12, 10))
        correlation = df.corr()
        sns.heatmap(correlation, annot=True, fmt='.2f', cmap='coolwarm', 
                   square=True, linewidths=0.5, cbar_kws={"shrink": 0.8})
        plt.title('Feature Correlation Heatmap')
        plt.tight_layout()
        plt.savefig('results/correlation_heatmap.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 3. Age distribution by target
        plt.figure(figsize=(10, 6))
        df[df['target']==0]['age'].hist(alpha=0.5, bins=20, label='No Disease', color='lightcoral')
        df[df['target']==1]['age'].hist(alpha=0.5, bins=20, label='Disease', color='lightblue')
        plt.xlabel('Age')
        plt.ylabel('Frequency')
        plt.title('Age Distribution by Target')
        plt.legend()
        plt.tight_layout()
        plt.savefig('results/age_distribution.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        # 4. Feature distributions
        fig, axes = plt.subplots(4, 3, figsize=(15, 12))
        fig.suptitle('Feature Distributions', fontsize=16)
        
        numeric_columns = df.select_dtypes(include=[np.number]).columns.tolist()
        if 'target' in numeric_columns:
            numeric_columns.remove('target')
        
        for idx, col in enumerate(numeric_columns[:12]):
            ax = axes[idx // 3, idx % 3]
            df[col].hist(bins=20, ax=ax, color='skyblue', edgecolor='black')
            ax.set_title(col)
            ax.set_xlabel('Value')
            ax.set_ylabel('Frequency')
        
        plt.tight_layout()
        plt.savefig('results/feature_distributions.png', dpi=300, bbox_inches='tight')
        plt.close()
        
        print("✓ EDA plots saved to 'results' directory")
    
    def clean_data(self, df):
        """Clean the dataset by handling missing values and outliers"""
        print("\n" + "="*80)
        print("DATA CLEANING")
        print("="*80)
        
        # Make a copy to avoid modifying original
        df_clean = df.copy()
        
        # Handle missing values
        missing_count = df_clean.isnull().sum().sum()
        if missing_count > 0:
            print(f"\n⚠ Found {missing_count} missing values")
            # Drop rows with missing values (for simplicity)
            # Alternative: use imputation
            df_clean = df_clean.dropna()
            print(f"✓ Dropped rows with missing values. New shape: {df_clean.shape}")
        else:
            print("✓ No missing values found")
        
        # Convert target to binary (0 or 1)
        # Original dataset has values 0-4, where 0=no disease, 1-4=disease
        if df_clean['target'].max() > 1:
            df_clean['target'] = (df_clean['target'] > 0).astype(int)
            print("✓ Converted multi-class target to binary")
        
        # Remove duplicates
        duplicates = df_clean.duplicated().sum()
        if duplicates > 0:
            df_clean = df_clean.drop_duplicates()
            print(f"✓ Removed {duplicates} duplicate rows")
        else:
            print("✓ No duplicate rows found")
        
        print(f"\n✓ Data cleaning complete. Final shape: {df_clean.shape}")
        return df_clean
    
    def prepare_features(self, df, test_size=0.2, random_state=42):
        """
        Prepare features for model training
        Split data and apply feature scaling
        """
        print("\n" + "="*80)
        print("FEATURE PREPARATION")
        print("="*80)
        
        # Separate features and target
        X = df.drop('target', axis=1)
        y = df['target']
        
        self.feature_names = X.columns.tolist()
        
        print(f"\n📊 Features shape: {X.shape}")
        print(f"📊 Target shape: {y.shape}")
        
        # Split data
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=test_size, random_state=random_state, stratify=y
        )
        
        print(f"\n✓ Data split:")
        print(f"  Training set: {X_train.shape[0]} samples")
        print(f"  Test set: {X_test.shape[0]} samples")
        
        # Feature scaling
        X_train_scaled = self.scaler.fit_transform(X_train)
        X_test_scaled = self.scaler.transform(X_test)
        
        # Convert back to DataFrame to preserve column names
        X_train_scaled = pd.DataFrame(X_train_scaled, columns=X.columns, index=X_train.index)
        X_test_scaled = pd.DataFrame(X_test_scaled, columns=X.columns, index=X_test.index)
        
        print("✓ Features scaled using StandardScaler")
        
        return X_train_scaled, X_test_scaled, y_train, y_test
    
    def save_processed_data(self, X_train, X_test, y_train, y_test, directory='data'):
        """Save processed data to disk"""
        os.makedirs(directory, exist_ok=True)
        
        # Combine features and target
        train_data = X_train.copy()
        train_data['target'] = y_train
        
        test_data = X_test.copy()
        test_data['target'] = y_test
        
        # Save to CSV
        train_data.to_csv(os.path.join(directory, 'train_data.csv'), index=False)
        test_data.to_csv(os.path.join(directory, 'test_data.csv'), index=False)
        
        print(f"\n✓ Processed data saved to '{directory}' directory")


if __name__ == "__main__":
    # Example usage
    preprocessor = DataPreprocessor()
    
    # Load data
    df = preprocessor.load_data()
    
    # Explore data
    preprocessor.explore_data(df)
    
    # Clean data
    df_clean = preprocessor.clean_data(df)
    
    # Prepare features
    X_train, X_test, y_train, y_test = preprocessor.prepare_features(df_clean)
    
    # Save processed data
    preprocessor.save_processed_data(X_train, X_test, y_train, y_test)
