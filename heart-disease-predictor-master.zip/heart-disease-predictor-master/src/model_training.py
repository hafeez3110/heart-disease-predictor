"""
Model training module for Heart Disease Prediction
Implements multiple ML algorithms and hyperparameter tuning
"""
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import GridSearchCV, cross_val_score
import numpy as np
import warnings
warnings.filterwarnings('ignore')


class ModelTrainer:
    """Class to handle model training and hyperparameter tuning"""
    
    def __init__(self):
        self.models = {}
        self.best_models = {}
        self.cv_scores = {}
        
    def initialize_models(self):
        """Initialize all ML models with default parameters"""
        self.models = {
            'Logistic Regression': LogisticRegression(max_iter=1000, random_state=42),
            'K-Nearest Neighbors': KNeighborsClassifier(),
            'Support Vector Machine': SVC(probability=True, random_state=42),
            'Decision Tree': DecisionTreeClassifier(random_state=42),
            'Random Forest': RandomForestClassifier(random_state=42)
        }
        print("✓ Models initialized successfully")
        return self.models
    
    def train_basic_models(self, X_train, y_train):
        """Train all models with default parameters"""
        print("\n" + "="*80)
        print("TRAINING BASIC MODELS")
        print("="*80)
        
        trained_models = {}
        
        for name, model in self.models.items():
            print(f"\n🔧 Training {name}...")
            model.fit(X_train, y_train)
            trained_models[name] = model
            print(f"✓ {name} trained successfully")
        
        self.best_models = trained_models
        return trained_models
    
    def perform_cross_validation(self, X_train, y_train, cv=5):
        """Perform k-fold cross-validation on all models"""
        print("\n" + "="*80)
        print("CROSS-VALIDATION")
        print("="*80)
        
        print(f"\nPerforming {cv}-fold cross-validation...")
        
        for name, model in self.models.items():
            scores = cross_val_score(model, X_train, y_train, cv=cv, scoring='accuracy')
            self.cv_scores[name] = scores
            print(f"\n{name}:")
            print(f"  CV Scores: {scores}")
            print(f"  Mean CV Score: {scores.mean():.4f} (+/- {scores.std() * 2:.4f})")
        
        return self.cv_scores
    
    def tune_hyperparameters(self, X_train, y_train, cv=5):
        """Perform hyperparameter tuning using GridSearchCV"""
        print("\n" + "="*80)
        print("HYPERPARAMETER TUNING")
        print("="*80)
        
        # Define parameter grids for each model
        param_grids = {
            'Logistic Regression': {
                'C': [0.001, 0.01, 0.1, 1, 10, 100],
                'penalty': ['l2'],
                'solver': ['lbfgs', 'liblinear']
            },
            'K-Nearest Neighbors': {
                'n_neighbors': [3, 5, 7, 9, 11],
                'weights': ['uniform', 'distance'],
                'metric': ['euclidean', 'manhattan']
            },
            'Support Vector Machine': {
                'C': [0.1, 1, 10],
                'kernel': ['rbf', 'linear'],
                'gamma': ['scale', 'auto']
            },
            'Decision Tree': {
                'max_depth': [3, 5, 7, 10, None],
                'min_samples_split': [2, 5, 10],
                'min_samples_leaf': [1, 2, 4],
                'criterion': ['gini', 'entropy']
            },
            'Random Forest': {
                'n_estimators': [50, 100, 200],
                'max_depth': [5, 10, None],
                'min_samples_split': [2, 5],
                'min_samples_leaf': [1, 2]
            }
        }
        
        tuned_models = {}
        
        for name, model in self.models.items():
            print(f"\n🔧 Tuning {name}...")
            
            # Perform grid search
            grid_search = GridSearchCV(
                model, 
                param_grids[name], 
                cv=cv, 
                scoring='accuracy',
                n_jobs=-1,
                verbose=0
            )
            
            grid_search.fit(X_train, y_train)
            
            # Store best model
            tuned_models[name] = grid_search.best_estimator_
            
            print(f"✓ Best parameters for {name}:")
            for param, value in grid_search.best_params_.items():
                print(f"    {param}: {value}")
            print(f"  Best CV Score: {grid_search.best_score_:.4f}")
        
        self.best_models = tuned_models
        print("\n✓ Hyperparameter tuning completed")
        return tuned_models
    
    def get_best_models(self):
        """Return the best trained models"""
        return self.best_models
    
    def get_model_by_name(self, name):
        """Get a specific model by name"""
        return self.best_models.get(name, None)
    
    def train_single_model(self, model_name, X_train, y_train, tune=False, cv=5):
        """Train a single model with optional hyperparameter tuning"""
        if model_name not in self.models:
            print(f"✗ Model '{model_name}' not found")
            return None
        
        model = self.models[model_name]
        
        if tune:
            print(f"\n🔧 Training and tuning {model_name}...")
            # Use the tuning function for just this model
            temp_models = {model_name: model}
            self.models = temp_models
            tuned = self.tune_hyperparameters(X_train, y_train, cv)
            self.models = self.initialize_models()  # Restore all models
            return tuned[model_name]
        else:
            print(f"\n🔧 Training {model_name}...")
            model.fit(X_train, y_train)
            print(f"✓ {model_name} trained successfully")
            return model


class EnsembleModel:
    """Create ensemble models for improved predictions"""
    
    def __init__(self, models):
        self.models = models
    
    def voting_prediction(self, X):
        """Make predictions using majority voting"""
        predictions = []
        
        for model in self.models.values():
            pred = model.predict(X)
            predictions.append(pred)
        
        # Majority voting
        predictions = np.array(predictions)
        final_pred = np.apply_along_axis(
            lambda x: np.bincount(x).argmax(), 
            axis=0, 
            arr=predictions
        )
        
        return final_pred
    
    def weighted_prediction(self, X, weights):
        """Make predictions using weighted voting"""
        predictions = []
        
        for model in self.models.values():
            pred_proba = model.predict_proba(X)[:, 1]
            predictions.append(pred_proba)
        
        # Weighted average
        predictions = np.array(predictions)
        weighted_avg = np.average(predictions, axis=0, weights=weights)
        final_pred = (weighted_avg > 0.5).astype(int)
        
        return final_pred


if __name__ == "__main__":
    # Example usage
    from src.data_preprocessing import DataPreprocessor
    
    # Load and prepare data
    preprocessor = DataPreprocessor()
    df = preprocessor.load_data()
    df_clean = preprocessor.clean_data(df)
    X_train, X_test, y_train, y_test = preprocessor.prepare_features(df_clean)
    
    # Initialize and train models
    trainer = ModelTrainer()
    trainer.initialize_models()
    
    # Train basic models
    trained_models = trainer.train_basic_models(X_train, y_train)
    
    # Perform cross-validation
    cv_scores = trainer.perform_cross_validation(X_train, y_train)
    
    # Tune hyperparameters (optional - takes longer)
    # tuned_models = trainer.tune_hyperparameters(X_train, y_train)
